import React, { useEffect } from "react";
import "./movieList.css";
import { useParams } from "react-router-dom";
import Cards from "../card/card";
import Pagination from "../pagination/pagination";
import { useSelector, useDispatch } from "react-redux";
import { moviesActions } from "../../store/movie-slice";
import { fetchMovies } from "../../store/movie-actions";

const MovieList = () => {
  const { movieList, currentPage, totalPages } = useSelector((state) => state);

  const { type } = useParams();

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(
      moviesActions.handleCurrentPageChange({
        currentPage: 1,
      })
    );
    const url = `https://api.themoviedb.org/3/movie/${
      type ? type : "popular"
    }?api_key=16e5963cd2200d56668671291e0feb3d&language=en-US&page=1`;

    dispatch(fetchMovies(url, "MOVIELIST"));
  }, [type, dispatch]);

  const handlePageChange = (page) => {
    dispatch(
      moviesActions.handleCurrentPageChange({
        currentPage: page,
      })
    );

    const url = `https://api.themoviedb.org/3/movie/${
      type ? type : "popular"
    }?api_key=16e5963cd2200d56668671291e0feb3d&language=en-US&page=${page}`;

    dispatch(fetchMovies(url, "MOVIELIST"));
  };

  return (
    <div className="movie__list">
      <h2 className="list__title">{(type ? type : "Popular").toUpperCase()}</h2>
      <div className="list__cards">
        {Array.isArray(movieList) &&
          movieList.map((movie) => <Cards movie={movie} key={movie.id} />)}
      </div>
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
    </div>
  );
};

export default MovieList;
