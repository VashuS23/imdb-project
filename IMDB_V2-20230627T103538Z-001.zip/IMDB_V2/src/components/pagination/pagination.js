import React, { useState, useEffect } from "react";

const Pagination = ({ totalPages, currentPage, onPageChange }) => {
  const [displayedPages, setDisplayedPages] = useState([]);

  useEffect(() => {
    const updatePagination = (newCurrentPage) => {
      const range = 2; // Number of page numbers to display on each side of the current page

      let startPage = newCurrentPage - range;
      let endPage = newCurrentPage + range;

      if (startPage < 1) {
        startPage = 1;
        endPage = Math.min(totalPages, startPage + range * 2);
      }

      if (endPage > totalPages) {
        endPage = totalPages;
        startPage = Math.max(1, endPage - range * 2);
      }

      const pages = Array.from(
        { length: endPage - startPage + 1 },
        (_, index) => startPage + index
      );

      setDisplayedPages(pages);
    };
    updatePagination(currentPage);
  }, [currentPage, totalPages]);

  const handlePageChange = (pageNumber) => {
    if (pageNumber !== currentPage) {
      onPageChange(pageNumber);
    }
  };

  return (
    <div className="pagination">
      {currentPage > 1 && (
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          className="left"
        >
          &lt;
        </button>
      )}

      {displayedPages.map((pageNumber) => (
        <button
          key={pageNumber}
          onClick={() => handlePageChange(pageNumber)}
          className={pageNumber === currentPage ? "active" : ""}
        >
          {pageNumber}
        </button>
      ))}

      {currentPage < totalPages && (
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          className="right"
        >
          &gt;
        </button>
      )}
    </div>
  );
};

export default Pagination;
