import { moviesActions } from "./movie-slice";

export const fetchMovies = (url, type) => {
  return async (dispatch) => {
    const fetchData = async () => {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Could not fetch Movies");
      }
      const data = await response.json();
      return data;
    };
    try {
      const data = await fetchData();
      if (type === "MOVIELIST") {
        dispatch(
          moviesActions.fetchMovieList({
            movieList: data.results,
            totalPages: data.total_pages,
          })
        );
      }
      if (type === "POPULAR") {
        dispatch(
          moviesActions.fetchPopularMovies({ popularMovies: data.results })
        );
      }
      if (type === "MOVIEDETAILS") {
        dispatch(moviesActions.fetchMovieDetail({ currentMovieDetail: data }));
      }
    } catch (error) {
      console.log(error);
    }
  };
};
