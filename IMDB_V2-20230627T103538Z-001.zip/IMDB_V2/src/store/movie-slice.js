import { createSlice } from "@reduxjs/toolkit";

const movieSlice = createSlice({
  name: "movies",
  initialState: {
    movieList: [],
    popularMovies: [],
    currentMovieDetail: null,
    currentPage: 1,
    totalPages: 1,
  },
  reducers: {
    fetchMovieList(state, action) {
      state.movieList = action.payload.movieList;
      state.totalPages = action.payload.totalPages;
    },
    fetchPopularMovies(state, action) {
      state.popularMovies = action.payload.popularMovies;
    },
    fetchMovieDetail(state, action) {
      state.currentMovieDetail = action.payload.currentMovieDetail;
    },
    handleCurrentPageChange(state, action) {
      state.currentPage = action.payload.currentPage;
    },
  },
});

export const moviesActions = movieSlice.actions;
export default movieSlice;
